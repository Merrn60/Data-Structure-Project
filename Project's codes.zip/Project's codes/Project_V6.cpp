#include <iostream>
#include <string>
using namespace std;

//the functions that work:
//display_apartment, display_all, addfirstnode, addbegin, addafter, addend, deletefirst, deleteafter, deletelast, displaycertainnum, searchapartmentbynum, sort

//Esraa's part
class Apartment
{
public:
    int status;

    int num_of_rooms;
    int num_of_toilets;
    int num_of_balconies;

    int area;

    int floor_num;
    int flat_num;

    string address;

    int price;

    Apartment *next;

    Apartment(int num_of_rooms, int num_of_toilets, int flat_num, int floor_num, int price)
    {
        this->num_of_rooms = num_of_rooms;
        this->num_of_toilets = num_of_toilets;
        this->num_of_balconies = 3;
        this->flat_num = flat_num;
        this->floor_num = floor_num;

        this->price = price;

        area = 250;
        address = "3354, South George St., Oklahoma";
        status = 0;
        next = NULL;
    }

    void display_apartment()
    {
        cout << "Number of rooms: " << num_of_rooms << endl;
        cout << "Number of toilets: " << num_of_toilets << endl;
        cout << "Number of balconies: " << num_of_balconies << endl;
        cout << "The area of the apartment: " << area << endl;
        cout << "Price: " << price << endl;
        cout << "Address: " << endl;
        cout << "\tapartment number " << flat_num << ", " << "floor number " << floor_num << ", " << address << endl;
        cout << "--------------------------------------------------" << endl << endl;
    }
};

class List
{
public:
    Apartment *head;
    int listsize;
    //int location_of_apartment;

    //Ansar's part
    List()
    {
        head = NULL;
        listsize = 0;
        //location_of_apartment = 1;
    }

    //Ansar's part
    void AddFirstNode(int num_of_rooms, int num_of_toilets, int flat_num, int floor_num, int price)
    {
        if(head == NULL)
        {
            Apartment *ap;
                
            ap = new Apartment (num_of_rooms, num_of_toilets, flat_num, floor_num, price);
            ap->next = NULL;
            head = ap;
            listsize++;
        }
    }

    //Reem's part
    void addBegin(int num_of_rooms, int num_of_toilets, int flat_num, int floor_num, int price)
    {
        Apartment *newapartment = new Apartment(num_of_rooms, num_of_toilets, flat_num, floor_num, price);
        
        if (head == NULL)
        {
            this->AddFirstNode(num_of_rooms, num_of_toilets, flat_num, floor_num, price);
        }
        else
        {
            newapartment->next = head;
            head = newapartment;
        }

        listsize++;
    }

    //Reem's part
    void AddAfter(int num_of_rooms, int num_of_toilets, int flat_num, int floor_num, int price, int target)
    {
        int counter=1;

        Apartment *head_copy = head;
        Apartment *newapartment= new Apartment(num_of_rooms, num_of_toilets, flat_num, floor_num, price);

        if(target == listsize)
        {
            this->AppendEnd(num_of_rooms, num_of_toilets, flat_num, floor_num, price);
            return;
        }

        while (counter < listsize)
        {
            if (counter==target)
            {
                newapartment->next = head_copy->next;
                head_copy->next = newapartment;
                break;
            }

            head_copy = head_copy->next;
            counter++;
        }

        listsize++;
    }

    //Ansar's part
    void AppendEnd(int num_of_rooms, int num_of_toilets, int flat_num, int floor_num, int price)
    {
        Apartment *new_ap, *head_copy = head;
        new_ap = new Apartment (num_of_rooms, num_of_toilets, flat_num, floor_num, price);

        //going to the end of the list
        while(head_copy->next != NULL)
        {
            head_copy = head_copy->next;
        }

        head_copy->next = new_ap;
        new_ap->next = NULL;

        listsize++;
    }

    //Reem's delete function
    void delete_first() 
    {
        head = head->next;        
    }

    //Esraa's delete function
    void delete_after (int index)
    {
        int counter = 1;
        Apartment*head_copy = head;
        if (index == 1)
        {
            delete_first();
        }
        else
        {
            while (counter < index)
            {
                head_copy = head_copy->next;
                counter ++;
            }
            head_copy->next = head_copy->next->next;
            listsize--;
        }
    }

    //Esraa's delete function
    void delete_last()
    {
        Apartment*head_copy = head;

        while (head_copy->next->next != NULL)
        {
            head_copy = head_copy->next;
        }

        head_copy->next = NULL;
        listsize--;
    }

    //Ansar's part
    int search_by_ap_num(int apartment_num)
    {
        int location_of_apartment=1;
        Apartment *head_copy = head;

        while(head_copy->flat_num != apartment_num && head_copy->next != NULL)
        {
            head_copy = head_copy->next;
            location_of_apartment++;
        }

        return location_of_apartment;
    }

    //Ansar's part

    //make a function that displays an apartment by its number
    void display_certain_num(int apartment_num)
    {
        Apartment *head_copy = head;
        int counter=1;

        while(counter != search_by_ap_num(apartment_num))
        {
            head_copy = head_copy->next;
            counter++;
        }

        head_copy->display_apartment();
    }

    //Ansar's part

    //displays all the info of the nodes
    void display_all()
    {
        Apartment *head_copy = head ;

        while(head_copy != NULL && head_copy->status == 0)
        {
            head_copy->display_apartment();
            head_copy = head_copy->next;
        }
    }

    //Reem's sort function

    //sorts the apartments in relation with the purchase price
    void sort()
    {
        int memory;
        Apartment *head_copy = head;
        Apartment *compared = NULL;
        if (head == NULL)
        {
            return;
        }

        while(head_copy!=NULL )
        {
            compared = head_copy->next;

            while (compared != NULL)
            {
                if (head_copy->price > compared->price)
                {
                    memory =head_copy ->price;
                    head_copy->price= compared->price;
                    compared->price= memory;
                }

                compared = compared->next;
            }

            head_copy= head_copy->next;
        }
    }

    void update(string choice, int duration, int apartment_num)
    {
        Apartment *head_copy = head;

        while(head_copy->flat_num != apartment_num)
        {
            head_copy = head_copy->next;
        }

        if(choice == "r")
        {
            head_copy->status = 2; //is rented
            head_copy->price = head_copy->price * duration;
        }
        else
        {
            head_copy->status = 1; //is purchased
            head_copy->price = head_copy->price * 100;
        }
    }
};

//Salma's part
class stack
{
public:
    int head;//(head)apartment
    int *list;//(array)list of apartments
    int max;//(max)number of apartments
    stack(int max_number)
    {   
        max = max_number;
        head=-1;
        list =new int[head];
    }

    //check if the list is full or not
    bool is_full()
    {   
        if(head==max-1)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    //check if the list is empty or not
    bool is_empty()
    {   
        if(head=-1)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    //add apartments to the list
    void push(int new_apartment)//new_data
    {
        head++;
        list[head]=new_apartment;//arr[head]=new_data
    }

    //remove apartments from the list
    void pop()
    {
        if(head>=0)
        {   int temp=list[head];
            list[head]=0;
            head--;
        }
    }
    // print the list of apartments
    void peak()
    {
        int i=head;
        while(i>=0)
        {          
            cout << list[i] << endl;
            i--;
        }
    }
};

//Rawan's part
int main() {
    int wanted_price, duration, apartment_num;
    string choice;

    List aps;

    cout << "Enter your choice: ";
    cin >> choice;

    aps.AddFirstNode(5 ,3, 1, 0, 4000);
    aps.AppendEnd(5, 2, 6, 2, 8000);
    aps.addBegin(4, 6, 2, 0, 3000);
    aps.AddAfter(3, 2, 4, 1, 2000, 2);

    if(choice == "r")
    {
        cout << "Enter duration: ";
        cin >> duration;
    }

    aps.sort();

    aps.display_all();

    cout << "Enter apartment num: ";
    cin >> apartment_num;

    aps.update(choice, duration, apartment_num);
    aps.display_certain_num(apartment_num);

    aps.display_all();

    return 0;
}