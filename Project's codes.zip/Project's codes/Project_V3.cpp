#include <iostream>
#include <string>
using namespace std;

class Apartment
{
public:
    int status; //1 if purchased, 2 if rented, 0 if none.

    int num_of_rooms;
    int num_of_toilets;
    int num_of_balconies;

    int area; //a default size

    int floor_num;
    int flat_num;

    string address; //default

    int rental_price; //per month.
    int purchase_price;

    Apartment *next;

    //the parameters will be filled later
    Apartment(int num_of_rooms, int num_of_toilets, int num_of_balcony, int flat_num, int floor_num, int rental_price, int purchase_price, int duration)
    {
        this->num_of_rooms = num_of_rooms;
        this->num_of_toilets = num_of_toilets;
        this->num_of_balconies = num_of_balconies;
        this->flat_num = flat_num;
        this->floor_num = floor_num;
        this->rental_price = rental_price * duration;
        this->purchase_price = purchase_price;
        area = 250;
        address = "3354, South George St., Oklahoma";
        status = 0;
        next = NULL;
    }

    void display_apartment()
    {
        cout << "Number of rooms: " << num_of_rooms << endl;
        cout << "Number of toilets: " << num_of_toilets << endl;
        cout << "Number of balconies: " << num_of_balconies << endl;
        cout << "The area of the apartment: " << area << endl;
        cout << "Rental price: " << rental_price << endl;
        cout << "Purchase price: " << purchase_price << endl;
        cout << "Address: " << endl;
        cout << "apartment number " << flat_num << ", " << "floor number " << floor_num << ", " << address << endl;
        cout << "--------------------------------------------------" << endl << endl;
    }
};

class List
{
public:
    Apartment *head;
    int listsize;
    int location_of_apartment;

    List()
    {
        head = NULL;
        listsize = 0;
        location_of_apartment = 1;
    }

    void AddFirstNode(int num_of_rooms, int num_of_toilets, int num_of_balcony, int flat_num, int floor_num, int rental_price, int purchase_price, int duration)
    {
        if(head == NULL)
        {
            Apartment *ap;
            ap = new Apartment (num_of_rooms, num_of_toilets, num_of_balcony, flat_num, floor_num, rental_price, purchase_price, duration);
            ap->next = NULL;
            head = ap;
            listsize++;
        }
    }

    //Reem's part
    void addBegin(int num_of_rooms, int num_of_toilets, int num_of_balcony, int flat_num, int floor_num, int rental_price, int purchase_price, int duration)
    {
        Apartment *newapartment = new Apartment(num_of_rooms, num_of_toilets, num_of_balcony, flat_num, floor_num, rental_price, purchase_price, duration);
        
        if (head == NULL)
        {
            this->AddFirstNode(num_of_rooms, num_of_toilets, num_of_balcony, flat_num, floor_num, rental_price, purchase_price, duration);
        }
        else
        {
            newapartment->next = head;
            head = newapartment;
        }

        listsize++;
    }

    //Reem's part
    void AddAfter(int num_of_rooms, int num_of_toilets, int num_of_balcony, int flat_num, int floor_num, int rental_price, int purchase_price, int duration, int target)
    {
        int counter=0;

        Apartment *head_copy = head;
        Apartment *newapartment= new Apartment(num_of_rooms, num_of_toilets, num_of_balcony, flat_num, floor_num, rental_price, purchase_price, duration);

        if(target == listsize)
        {
            this->AppendEnd(num_of_rooms, num_of_toilets, num_of_balcony, flat_num, floor_num, rental_price, purchase_price, duration);
            return;
        }

        while (counter < listsize)
        {
            if (counter==target)
            {
                newapartment->next = head_copy->next;
                head_copy->next = newapartment;
                break;
            }

            head_copy = head_copy->next;
            counter++;
        }

        listsize++;
    }

    void AppendEnd(int num_of_rooms, int num_of_toilets, int num_of_balcony, int flat_num, int floor_num, int rental_price, int purchase_price, int duration)
    {
        Apartment *new_ap, *head_copy = head;
        new_ap = new Apartment (num_of_rooms, num_of_toilets, num_of_balcony, flat_num, floor_num, rental_price, purchase_price, duration);

        //going to the end of the list
        while(head_copy->next != NULL)
        {
            head_copy = head_copy->next;
        }

        head_copy->next = new_ap;
        new_ap->next = NULL;

        listsize++;
    }

    //checks whether the price/month entered exists or not
    //returns the number of the node that has that price, starting from node 1 as number 1.
    //returns 0 if there is no similar price.

    //write search by apartment number
    int search_by_ap_num(int apartment_num)
    {
        Apartment *head_copy = head;

        while(head_copy->flat_num != apartment_num)
        {
            head_copy = head_copy->next;
            location_of_apartment++;
        }

        return location_of_apartment;
    } 


    int search_by_price(int wanted_price, int duration)
    {
        Apartment *head_copy = head;
        int node_num=0;

        //search for the price
        while(head_copy != NULL)
        {
            if((wanted_price*duration) == head_copy->rental_price)
            {
                node_num++;
                return node_num;
            }
            else
            {
                head_copy = head_copy->next;
            }

        }

        return node_num;
    }

    //make a function that displays an apartment by its number
    void display_certain_num()
    {
        Apartment *head_copy = head;
        int counter=1;

        while(counter != location_of_apartment)
        {
            head_copy = head_copy->next;
        }

        head_copy->display_apartment();
    }

    //displays all the info of the nodes
    void display_all()
    {
        Apartment *head_copy = head ;

        while(head_copy != NULL)
        {
            while(head_copy->status == 0) // is not rented or purchased
            {
                head_copy->display_apartment();
                head_copy = head_copy->next;
            }
            
        }
    }
};

//stack class definition
class stack{
public:
    int head;//(head)apartment
    int *list;//(array)list of apartments
    int max;//(max)number of apartments
    stack(int max_number)
    {   
        max = max_number;
        head=-1;
        list =new int[head];
    }

    //check if the list is full or not
    bool is_full()
    {   
        if(head==max-1)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    //check if the list is empty or not
    bool is_empty()
    {   
        if(head=-1)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    //add apartments to the list
    void push(int new_apartment)//new_data
    {
        head++;
        list[head]=new_apartment;//arr[head]=new_data
    }

    //remove apartments from the list
    void pop()
    {
        if(head>=0)
        {   int temp=list[head];
            list[head]=0;
            head--;
        }
    }
    // print the list of apartments
    void peak()
    {
        int i=head;
        while(i>=0)
        {          
            cout << list[i] << endl;
            i--;
        }
    }
};

int main() {
    //stack *s=new stack(3);
    int wanted_price, duration;

    List aps;

    cout << "Enter the duration: ";
    cin >> duration;
    aps.AddFirstNode(5, 2, 3, 1, 0, 6000, 60000, duration);

    // cout << "Enter the duration: ";
    // cin >> duration;
    // aps.Add_Node_Beginning(3, 1, 1, 2, 0, 3000, 30000, duration);

    cout << "Enter the duration: ";
    cin >> duration;
    aps.AppendEnd(5, 2, 3, 6, 2, 8000, 80000, duration);

    cout << "Enter the wanted price: ";
    cin >> wanted_price;

    aps.display_all();

    return 0;
}

/*void update(string choice)
{
    if(choice == "r")
    {
        status = 2;
    }
    else
    {
        status = 1;
    }
}*/