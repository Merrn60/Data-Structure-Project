#include <iostream>
#include <string>
using namespace std;

//Check Salma's part.

class Apartment
{
    public:
        int status; //1 if purchased, 2 if rented, 0 if none.

        int num_of_rooms;
        int num_of_toilets;
        int num_of_balconies;

        int area; //a default size

        int floor_num;
        int flat_num;

        string city_name; //default
        string street_name; //default
        string owner_name; //changed in main

        int building_num; //default
        
        int rental_price; //per month.
        int purchase_price;
        
        Apartment *next;

        //the parameters will be filled later
        Apartment(int num_of_rooms, int num_of_toilets, int num_of_balcony, int flat_num, int floor_num, int rental_price, int purchase_price, int duration)
        {
            this->num_of_rooms = num_of_rooms;
            this->num_of_toilets = num_of_toilets;
            this->num_of_balconies = num_of_balconies;
            this->flat_num = flat_num;
            this->floor_num = floor_num;
            this->rental_price = rental_price * duration;
            this->purchase_price = purchase_price;
            area = 250;
            city_name = "Oklahoma";
            street_name = "South George St.";
            building_num = 3354;
            status = 0;
            next = NULL;
        }

        void display_apartment()
        {
            cout << "Number of rooms: " << num_of_rooms << endl;
            cout << "Number of toilets: " << num_of_toilets << endl;
            cout << "Number of balconies: " << num_of_balconies << endl;
            cout << "The area of the apartment: " << area << endl;
            cout << "Rental price: " << rental_price << endl;
            cout << "Purchase price: " << purchase_price << endl;
            cout << "Address: " << endl;
            cout << "City: " << city_name << "\tStreet: " << street_name << "\tBuilding number: " << building_num << "\tFlat number: " << flat_num << "\tFloor number: " << floor_num << endl;
            cout << "--------------------------------------------------" << endl;
        }
};

class List
{
    public:
        Apartment *head;

        List()
        {
            head = NULL;
        }

        void AddFirstNode(int num_of_rooms, int num_of_toilets, int num_of_balcony, int flat_num, int floor_num, int rental_price, int purchase_price, int duration)
        {
            Apartment *ap;
            ap = new Apartment (num_of_rooms, num_of_toilets, num_of_balcony, flat_num, floor_num, rental_price, purchase_price, duration);
            ap->next = NULL;
            head = ap;
        }

        void Add_Node_Beginning(int num_of_rooms, int num_of_toilets, int num_of_balcony, int flat_num, int floor_num, int rental_price, int purchase_price, int duration)
        {
            Apartment *ap;
            ap = new Apartment (num_of_rooms, num_of_toilets, num_of_balcony, flat_num, floor_num, rental_price, purchase_price, duration);
            ap->next = head;
            head = ap;
        }

        void AppendEnd(int num_of_rooms, int num_of_toilets, int num_of_balcony, int flat_num, int floor_num, int rental_price, int purchase_price, int duration)
        {
            Apartment *ap, *head_copy;
            head_copy = head;

            //going to the end of the list
            while(head_copy->next != NULL)
            {
                head_copy = head_copy->next;
            }

            head_copy->next = new Apartment (num_of_rooms, num_of_toilets, num_of_balcony, flat_num, floor_num, rental_price, purchase_price, duration);
            head_copy->next->next = NULL;
        }

        //this function adds a node after another with a distinct price
        void AddAfter(int num_of_rooms, int num_of_toilets, int num_of_balcony, int flat_num, int floor_num, int rental_price, int purchase_price, int duration, int wanted_price)
        {
            Apartment *head_copy, *ap;
            head_copy = head;

            if(!search_by_price(wanted_price, duration))
            {
                cout << "Error: Apartment with the given price is not found." << endl;
            }
            else
            {
                ap = new Apartment (num_of_rooms, num_of_toilets, num_of_balcony, flat_num, floor_num, rental_price, purchase_price, duration);

                ap->next = head_copy->next;
                head_copy->next = ap;
            }
        }

        //checks whether the price/month entered exists or not
        bool search_by_price(int wanted_price, int duration)
        {
            Apartment *head_copy = head;

            //search for the price
            while(head_copy != NULL)
            {
                if((wanted_price*duration) == head_copy->rental_price)
                {
                    return true;
                }
                else
                {
                    head_copy = head_copy->next;
                }

            }

            return false;
        }

        //displays all the info of the nodes
        void display()
        {
            Apartment *head_copy = head ;

            while(head_copy != NULL)
            {
                head_copy->display_apartment();
                head_copy = head_copy->next;
            }
        }
};

//stack class definition
/*class stack{
    public:
        int apartment;//the apartment you want
        int *list_of_apartments;//list of apartments
        int number_of_apartments;//number of apartments
        stack(int number)
        {
            number_of_apartments=number;
            apartment=-1;
            list_of_apartments =new int[number_of_apartments];
        }

        //check if the list is full or not
        bool is_full() 
        {
            if(apartment==number_of_apartments-1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        //check if the list is empty or not
        bool is_empty() 
        {
            if(apartment=-1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        //add apartments to the list
        void push(int new_apartment) 
        {
            apartment++;
            list_of_apartments[apartment]=new_apartment;
        }

        //remove apartments from the list
        void pop() 
        {
            if(apartment>=0) 
            {
                list_of_apartments[apartment]=0;
                apartment--;
            }
        }

        //print the list of apartments
        void peak() 
        {
            int i=apartment;
            while(i>=0) 
            {
                cout << list_of_apartments[i] << endl;
                i--;
            }
        }
};*/

int main() {
    //stack *s=new stack(3);
    int wanted_price, duration;

    List aps;

    cout << "Enter the duration: ";
    cin >> duration;
    aps.AddFirstNode(5, 2, 3, 1, 0, 6000, 60000, duration);

    cout << "Enter the duration: ";
    cin >> duration;
    aps.Add_Node_Beginning(3, 1, 1, 2, 0, 3000, 30000, duration);

    cout << "Enter the duration: ";
    cin >> duration;
    aps.AppendEnd(5, 2, 3, 6, 3, 8000, 80000, duration);

    cout << "Enter the wanted price: ";
    cin >> wanted_price;
    cout << "Enter the duration: ";
    cin >> duration;
    aps.AddAfter(3, 1, 1, 5, 3, 5000, 50000, duration, wanted_price);

    aps.display();

    return 0;
}